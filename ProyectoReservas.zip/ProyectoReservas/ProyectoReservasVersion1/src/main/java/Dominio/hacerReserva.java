package Dominio;

import java.util.ArrayList;
import java.util.Iterator;

public class hacerReserva {
	private hacerReserva nombre;
	
	private ArrayList<reserva> hacerReserva;
	
	public hacerReserva() {
        this.hacerReserva = new ArrayList<reserva>();
    }
	

	
	 public ArrayList<reserva> getListaReservas() {
	        return this.hacerReserva;
	    }
	
	 
	 /*
	public String mostrarListaReservas() {
        String lista = "";
        
        Iterator it = hacerReserva.iterator();
        
        reserva r = (r) it.next();
        
        while (it.hasNext()) {
        	lista += r.getNombreReserva();
        }
        
		return lista;
    }
	*/
	 
	  
	    public String mostrarListaReservas() {
	        String lista = "";
	        for (final reserva r : this.getListaReservas()) {
	            lista = String.valueOf(lista) + "\nReserva: " + r.getIdReserva() + " - " +  r.getNombreReserva() + ".";
	        }
	        return lista;
	    }
	    
	public ArrayList<reserva> getNuevaReserva(){
		return this.hacerReserva;
	}
	public void anadirReserva(final reserva r) {
		hacerReserva.add(r);
		
	}
	public hacerReserva getNombre () {
	return this.nombre;
	}
	
}
