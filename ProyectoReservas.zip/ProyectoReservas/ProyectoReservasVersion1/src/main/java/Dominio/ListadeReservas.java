package Dominio;

import java.util.ArrayList;
import java.util.Iterator;

public class ListadeReservas {
	
	private ArrayList<reserva> ListadeReservas;
    
    public ListadeReservas() {
        this.ListadeReservas = new ArrayList<reserva>();
    }
    
    public ArrayList<reserva> getListaReservas() {
        return this.ListadeReservas;
    }
    
    public reserva getIdReserva(final int IdReserva) {
        final Iterator it = this.ListadeReservas.iterator();
        if (it.hasNext()) {
            final reserva u = (reserva) it.next();
            if (IdReserva == u.getIdReserva()) {}
            return u;
        }
        return null;
    }
    
    public String mostrarListaReservas() {
        String lista = "";
        for (final reserva u : this.getListaReservas()) {
            lista = String.valueOf(lista) + "\nReservas realizadas: " + u.getIdReserva();
        }
        return lista;
    }
}
	


