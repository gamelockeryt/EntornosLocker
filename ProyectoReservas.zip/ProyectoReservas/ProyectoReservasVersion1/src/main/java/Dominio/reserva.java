package Dominio;

public class reserva {

	private int IdReserva;
	private String NombreReserva;

	public reserva(int IdReserva, String NombreReserva) {
		this.IdReserva = IdReserva;
		this.NombreReserva = NombreReserva;
	}

	public int getIdReserva() {
		return IdReserva;
	}

	public void setIdReserva(int idReserva) {
		IdReserva = idReserva;
	}

	public String getNombreReserva() {
		return NombreReserva;
	}

	public void setNombreReserva(String nombreReserva) {
		NombreReserva = nombreReserva;
	}

}
