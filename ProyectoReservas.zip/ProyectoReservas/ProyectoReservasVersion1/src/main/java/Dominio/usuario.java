package Dominio;

public class usuario {
	private String usuario;
	private String contrase;

	public usuario(final String usuario, final String contrase) {
		this.usuario = usuario;
		this.contrase = contrase;
	}

	public String getUsuario() {
		return this.usuario;
	}

	public void setUsuario(final String usuario) {
		this.usuario = usuario;
	}

	public String getContrase() {
		return this.contrase;
	}

	public void setContrase(final String contrase) {
		this.contrase = contrase;
	}

	public boolean comprobarcontra(String usuario, String contra) {

		if (usuario.equals(this.usuario)&&(contra.contentEquals(this.contrase))) {
			return true;
		}
		else
			return false;

	}
}