package Dominio;

import java.util.Iterator;
import java.util.ArrayList;

public class listaUsuarios
{
    private ArrayList<usuario> listaUsuarios;
    
    public listaUsuarios() {
        this.listaUsuarios = new ArrayList<usuario>();
    }
    
    public void anadirUsuario(final usuario u) {
        this.listaUsuarios.add(u);
    }
    
    public ArrayList<usuario> getListaUsuario() {
        return this.listaUsuarios;
    }
    
    public usuario getUsuarioUser(final String usuario) {
        final Iterator it = this.listaUsuarios.iterator();
        if (it.hasNext()) {
            final usuario u = (usuario) it.next();
            if (usuario == u.getUsuario()) {}
            return u;
        }
        return null;
    }
    
    public boolean getUsuarioPass(final String contrase) {
        final Iterator it = this.listaUsuarios.iterator();
        if (it.hasNext()) {
            final usuario u = (usuario) it.next();
            if (contrase == u.getContrase()) {}
            return true;
        }
        return false;
    }
    
    
    
    public String mostrarListaUsuarios() {
        String lista = "";
        for (final usuario u : this.getListaUsuario()) {
            lista = String.valueOf(lista) + "\nUsuario: " + u.getUsuario() + " Contrasenya: " + u.getContrase();
        }
        return lista;
    }
}