package Dominio;

import java.util.ArrayList;
import java.util.Iterator;


public class hacerReserva {
	private hacerReserva nombre;
	
	private ArrayList<reserva> hacerReserva;
	
	public hacerReserva() {
        this.hacerReserva = new ArrayList<reserva>();
    }
	

	
	 public ArrayList<reserva> getListaReservas() {
	        return this.hacerReserva;
	    }
	
	 
	 /*
	public String mostrarListaReservas() {
        String lista = "";
        
        Iterator it = hacerReserva.iterator();
        
        reserva r = (r) it.next();
        
        while (it.hasNext()) {
        	lista += r.getNombreReserva();
        }
        
		return lista;
    }
	*/
	 
	  
	    public String mostrarListaReservas() {
	        String lista = "";
	        for (final reserva r : this.getListaReservas()) {
	            lista = String.valueOf(lista) + "\nReserva: " + r.getIdReserva() + " - " +  r.getNombreReserva() + ".";
	        }
	        return lista;
	    }
	    
	public ArrayList<reserva> getNuevaReserva(){
		return this.hacerReserva;
	}
	
	public void anadirReserva(final reserva r) {
		hacerReserva.add(r);
		
	}
	public hacerReserva getNombre () {
	return this.nombre;
	}
	
	public void eliminarReserva (int i) {
		Iterator<reserva> it = hacerReserva.iterator();
		int index = -1;
		boolean ok = false;
		while (it.hasNext() && !ok) {
			reserva a = it.next();
			if (a.getIdReserva() == i) {
				ok = true;
			}
			index++;
		}
		if(ok) {
			this.hacerReserva.remove(index);
			System.out.println("Eliminada la reserva con id: " + i);
		}else {
			System.out.println("No se ha encontrado la reserva relacionada al id: " + i);
		}
	}
	
}
