
package Presentacion;

import java.util.Scanner;
import javax.swing.JOptionPane;

import Dominio.hacerReserva;
import Dominio.usuaryList;
import Dominio.reserva;
import Dominio.usuario;

public class principal {
	public static usuaryList usuarios;
	public static hacerReserva hacerReserva;

	static {
		principal.usuarios = new usuaryList();
		principal.hacerReserva = new hacerReserva();

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int opcion;
		boolean passOK = false;
		do {
			System.out.println("1. Registrarse\n2. Inicio sesion\n3. Salir");
			final Scanner entry = new Scanner(System.in);
			opcion = entry.nextInt();
			switch (opcion) {

			case 1:
				// case1();

				String user = JOptionPane.showInputDialog("User");
				String pass = JOptionPane.showInputDialog("Contrase�a");
				principal.usuarios.anadirUsuario(new usuario(user, pass));

				break;

			case 2:
				// case2();

				if (principal.usuarios.getListaUsuario().isEmpty()) {
					System.out.println("Tiene que registrarse\n");
				} else {

					do {
						final String comprobarUser = JOptionPane.showInputDialog("Introduce tu usuario");

						final String comprobarPass = JOptionPane.showInputDialog("Introduce tu contra");
						if (principal.usuarios.getUsuarioUser(comprobarUser).comprobarcontra(comprobarUser,
								comprobarPass) == true) {
							System.out.println("Bienvenido");
							passOK = true;
						} else {
							System.out.println("Introduce el usuario y/o la contrase�a correctamente");
							passOK = false;
						}
					} while (passOK == false);
				}

				break;

			}
		} while (opcion != 3 && passOK == false);

		int option;
		int i = 1;
		String id;
		
		do {
			
			final Scanner entrada = new Scanner(System.in);
			
			System.out.println("Zona de Reservas");

			System.out.println("1. Hacer una reserva");
			System.out.println("2. Consultar reservas");
			System.out.println("3. Eliminar reserva");
			System.out.println("4. Salir");
			
			
			option = entrada.nextInt();
			
			
			switch (option) {
			case 1:
							
				String nombreReserva = JOptionPane.showInputDialog("Nombre de la Reserva");
				
				principal.hacerReserva.anadirReserva(new reserva (i, nombreReserva));
				i++;
				
				break;
			case 2:
				
				if(principal.hacerReserva.getListaReservas().isEmpty()) {
					System.out.println("Aun no hay ninguna reserva, �A qu� esperas!!?");
				}else {
					System.out.println(principal.hacerReserva.mostrarListaReservas());
				}
				
				break;
			case 3:
				
				id = JOptionPane.showInputDialog("�Qu� reserva quiereres eliminar: ?");
				i= Integer.parseInt(id);
				principal.hacerReserva.eliminarReserva(i);
				System.out.println(principal.hacerReserva.mostrarListaReservas());
				
				

			}

		} while (option != 4);

	}
}
