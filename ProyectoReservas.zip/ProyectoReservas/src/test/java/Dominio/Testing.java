package Dominio;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

public class Testing {

	@Test
	public void eliminarReserva() {
		
		System.out.println("Estoy eliminando una reserva");
		
		String esperado = ("Eliminada la reserva con id: i");
	}
	
	

}
